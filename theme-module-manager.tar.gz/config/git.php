<?php
return [
    'token' => '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' // Simpan di sini sementara
];