<?php
namespace App\Core;

use App\Services\GitService;
use Exception;

class RepositoryManager
{
    private $gitService;
    private $basePath;
    private $repos;

    public function __construct()
    {
        $this->gitService = new GitService();
        $this->basePath = realpath(__DIR__ . '/../../');
        $this->loadReposConfig();
    }

    private function loadReposConfig(): void
    {
        $configFile = $this->basePath . '/config/repos.php';
        if (!file_exists($configFile)) {
            throw new Exception("Repository configuration file not found");
        }
        
        $this->repos = require $configFile;
    }

    public function getRepos(): array
    {
        return [
            'themes' => $this->repos['themes'] ?? [],
            'modules' => $this->repos['modules'] ?? []
        ];
    }

    public function syncRepo(string $type, string $name): array
    {
        $type = strtolower($type);
        $type = str_ends_with($type, 's') ? $type : $type . 's';

        $repoConfig = $this->repos[$type][$name] ?? null;
        
        if (!$repoConfig) {
            throw new Exception("Repository configuration not found for $type/$name");
        }

        $this->validateRepositoryConfig($repoConfig);

        $result = [
            'type' => $type,
            'name' => $name,
            'status' => '',
            'message' => '',
            'success' => false,
            'commit' => null
        ];

        try {
            $targetDir = $this->getRepoPath($type, $name);
            $repoToken = $repoConfig['token'] ?? null;

            if (!is_dir($targetDir)) {
                $result = $this->cloneNewRepo(
                    $repoConfig['url'],
                    $targetDir,
                    $repoConfig['branch'],
                    $result,
                    $repoToken
                );
            } elseif (!is_dir($targetDir . '/.git')) {
                $this->removeDirectory($targetDir);
                $result = $this->cloneNewRepo(
                    $repoConfig['url'],
                    $targetDir,
                    $repoConfig['branch'],
                    $result,
                    $repoToken
                );
            } else {
                $result = $this->updateExistingRepo($targetDir, $repoConfig, $result);
            }
        } catch (Exception $e) {
            // Clean up if failed during clone
            if (isset($targetDir) && is_dir($targetDir) && !is_dir($targetDir . '/.git')) {
                $this->removeDirectory($targetDir);
            }
            throw new Exception("Repository synchronization failed: " . $e->getMessage());
        }

        return $result;
    }

    private function validateRepositoryConfig(array $config): void
    {
        if (empty($config['url'])) {
            throw new Exception("Repository URL is required");
        }
        
        if (!filter_var($config['url'], FILTER_VALIDATE_URL)) {
            throw new Exception("Invalid repository URL format");
        }
        
        if (empty($config['branch'])) {
            throw new Exception("Repository branch is required");
        }
    }

    private function ensureDirectoryExists(string $path): void
    {
        if (!is_dir($path)) {
            if (!mkdir($path, 0775, true)) {
                throw new Exception("Failed to create directory: $path");
            }
            chmod($path, 0775);
        }
        
        if (!is_writable($path)) {
            throw new Exception("Directory is not writable: $path");
        }
    }

    private function removeDirectory(string $path): void
    {
        if (!is_dir($path)) {
            return;
        }

        $items = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($path, \RecursiveDirectoryIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($items as $item) {
            if ($item->isDir()) {
                rmdir($item->getRealPath());
            } else {
                unlink($item->getRealPath());
            }
        }

        rmdir($path);
    }

    public function isUpdateAvailable(string $type, string $name): bool
    {
        $localPath = $this->getRepoPath($type, $name);
        $repoConfig = $this->repos[$type][$name] ?? null;

        if (!$repoConfig || !is_dir($localPath)) {
            return false;
        }

        try {
            $localRepo = $this->gitService->openRepository($localPath);
            $localCommit = (string) $localRepo->getLastCommitId();

            $remoteInfo = $this->getRemoteRepoInfo(
                $repoConfig['url'],
                $repoConfig['branch'],
                $repoConfig['token'] ?? null
            );
            
            return $localCommit !== ($remoteInfo['version'] ?? null);
        } catch (Exception $e) {
            return false;
        }
    }

    private function updateExistingRepo(string $path, array $config, array $result): array
    {
        try {
            $repo = $this->gitService->openRepository($path);
            
            $repo->fetch('origin');
            $repo->execute('reset', '--hard', 'origin/' . $config['branch']);
            
            $result['status'] = 'updated';
            $result['message'] = "Repository updated successfully";
            $result['commit'] = (string) $repo->getLastCommitId();
            $result['success'] = true;
            
        } catch (Exception $e) {
            throw new Exception("Failed to update repository: " . $e->getMessage());
        }
        
        return $result;
    }

    private function cloneNewRepo(string $url, string $path, string $branch, array $result, ?string $repoToken = null): array
    {
        try {
            $this->ensureDirectoryExists(dirname($path));

            $repo = $this->gitService->cloneRepository(
                $url, 
                $path, 
                ['--branch' => $branch],
                $repoToken
            );

            if (!is_dir($path . '/.git')) {
                throw new Exception(".git directory not detected after clone");
            }

            $result['status'] = 'cloned';
            $result['message'] = "Repository cloned successfully";
            $result['commit'] = (string) $repo->getLastCommitId();
            $result['success'] = true;

        } catch (Exception $e) {
            if (is_dir($path)) {
                $this->removeDirectory($path);
            }
            throw new Exception("Clone failed: " . $e->getMessage());
        }
        
        return $result;
    }

    public function listInstalled(): array
    {
        $installed = ['themes' => [], 'modules' => []];

        foreach (['themes', 'modules'] as $type) {
            $dir = $this->basePath . "/repository/{$type}";
            if (is_dir($dir)) {
                $installed[$type] = $this->scanRepoDirectory($dir);
            }
        }

        return $installed;
    }

    private function scanRepoDirectory(string $dir): array
    {
        $repos = [];
        foreach (scandir($dir) as $item) {
            if ($this->isValidRepoItem($dir, $item)) {
                $repos[$item] = $this->getRepoInfo("$dir/$item");
            }
        }
        return $repos;
    }

    private function isValidRepoItem(string $dir, string $item): bool
    {
        return $item !== '.' && 
               $item !== '..' && 
               is_dir("$dir/$item/.git");
    }

    private function getRemoteRepoInfo(string $url, string $branch, ?string $token = null): array
    {
        $tempDir = sys_get_temp_dir() . '/git_temp_' . md5($url . $branch);
        
        try {
            $repo = $this->gitService->cloneRepository(
                $url,
                $tempDir,
                ['--branch' => $branch, '--depth' => '1'],
                $token
            );
            
            $info = [
                'version' => (string) $repo->getLastCommitId(),
                'branch' => $repo->getCurrentBranchName(),
                'has_changes' => false
            ];
            
            return $info;
        } catch (Exception $e) {
            return [
                'error' => $e->getMessage(),
                'version' => 'unknown',
                'branch' => $branch
            ];
        } finally {
            if (is_dir($tempDir)) {
                $this->removeDirectory($tempDir);
            }
        }
    }

    public function getRepoDetails(string $type, string $name): array
    {
        $targetDir = $this->getRepoPath($type, $name);
        $repoConfig = $this->repos[$type][$name] ?? null;
        
        $details = [
            'config' => $repoConfig,
            'installed' => is_dir($targetDir),
            'details' => [],
            'branches' => [],
            'tags' => [],
            'error' => null
        ];

        if ($details['installed']) {
            $details = $this->loadRepoDetails($targetDir, $details);
        } elseif ($repoConfig) {
            $details['details'] = $this->getRepoInfo(
                $targetDir,
                $repoConfig['url'],
                $repoConfig['branch'],
                $repoConfig['token'] ?? null
            );
        }

        return $details;
    }

    private function loadRepoDetails(string $path, array $details): array
    {
        try {
            $repo = $this->gitService->openRepository($path);
            
            $details['installed'] = true;
            $details['details'] = [
                'branch' => $repo->getCurrentBranchName(),
                'last_commit' => (string) $repo->getLastCommitId(),
                'has_changes' => $repo->hasChanges()
            ];
            
            $details['branches'] = $repo->getBranches();
            $details['tags'] = $repo->getTags();
            
        } catch (Exception $e) {
            $details['error'] = $e->getMessage();
        }

        return $details;
    }

    private function getRepoInfo(string $path, ?string $remoteUrl = null, ?string $branch = null, ?string $token = null): array {
        if (is_dir($path)) {
            try {
                $repo = $this->gitService->openRepository($path);
                return [
                    'version' => (string) $repo->getLastCommitId(),
                    'branch' => $repo->getCurrentBranchName(),
                    'has_changes' => $repo->hasChanges()
                ];
            } catch (Exception $e) {
                // Fall through to remote check
            }
        }
        
        if ($remoteUrl && $branch) {
            return $this->getRemoteRepoInfo($remoteUrl, $branch, $token);
        }
        
        return ['error' => 'Repository not available'];
    }

    private function getRepoPath(string $type, string $name): string
    {
        $type = strtolower($type);
        $dirName = str_ends_with($type, 's') ? $type : $type . 's';
        return $this->basePath . "/repository/{$dirName}/" . trim($name, '/');
    }

    public function getCommitHistory(string $type, string $name, int $limit = 10): array
    {
        $targetDir = $this->getRepoPath($type, $name);
        $history = [];

        try {
            if (!is_dir($targetDir)) {
                return [];
            }

            $repo = $this->gitService->openRepository($targetDir);
            $output = $repo->execute('log', "--pretty=format:%h|%s|%an|%ad", "--date=short", "-n", (string)$limit);
            
            $lines = is_array($output) ? $output : explode("\n", $output);
            
            foreach ($lines as $line) {
                if (!empty($line)) {
                    $parts = explode('|', $line, 4);
                    if (count($parts) === 4) {
                        [$hash, $message, $author, $date] = $parts;
                        $history[] = [
                            'hash' => $hash,
                            'message' => $message,
                            'author' => $author,
                            'date' => $date
                        ];
                    }
                }
            }
        } catch (Exception $e) {
            error_log("Error getting commit history: " . $e->getMessage());
            return [];
        }

        return $history;
    }

    public function rollback(string $type, string $name, string $commitHash): array
    {
        $targetDir = $this->getRepoPath($type, $name);
        $result = [
            'success' => false,
            'message' => '',
            'new_commit' => null
        ];

        try {
            $repo = $this->gitService->openRepository($targetDir);
            $repo->execute('reset', '--hard', $commitHash);
            
            $result['success'] = true;
            $result['message'] = "Rollback to $commitHash successful";
            $result['new_commit'] = (string) $repo->getLastCommitId();
            
        } catch (Exception $e) {
            $result['message'] = $e->getMessage();
        }

        return $result;
    }

    public function createBranch(string $type, string $name, string $branchName, bool $checkout = false): array
    {
        $targetDir = $this->getRepoPath($type, $name);
        $result = [
            'success' => false,
            'message' => ''
        ];

        try {
            $repo = $this->gitService->openRepository($targetDir);
            $repo->createBranch($branchName, $checkout);
            
            $result['success'] = true;
            $result['message'] = "Branch $branchName created" . ($checkout ? " and checked out" : "");
                               
        } catch (Exception $e) {
            $result['message'] = $e->getMessage();
        }

        return $result;
    }

    public function createTag(string $type, string $name, string $tagName, string $message = null): array
    {
        $targetDir = $this->getRepoPath($type, $name);
        $result = [
            'success' => false,
            'message' => ''
        ];

        try {
            $repo = $this->gitService->openRepository($targetDir);
            
            $options = $message ? ['-m' => $message] : [];
            $repo->createTag($tagName, $options);
            
            $result['success'] = true;
            $result['message'] = "Tag $tagName created";
            
        } catch (Exception $e) {
            $result['message'] = $e->getMessage();
        }

        return $result;
    }
}