<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h4 class="mb-0">
            <i class="bi bi-<?= ($data['type'] ?? '') === 'theme' ? 'palette' : 'puzzle' ?>"></i>
            <?= htmlspecialchars($data['name'] ?? 'Unknown Repository') ?>
        </h4>
        <div>
            <a href="./?page=dashboard" class="btn btn-sm btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Back
            </a>
            <?php if (isset($data['type'], $data['name'])): ?>
                <a href="./?page=sync&type=<?= htmlspecialchars($data['type']) ?>&name=<?= htmlspecialchars($data['name']) ?>" 
                   class="btn btn-sm btn-primary" data-action="sync">
                    <i class="bi bi-arrow-repeat"></i> Sync
                </a>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <h5>Repository Info</h5>
                <table class="table table-sm">
                    <tr>
                        <th width="30%">Type</th>
                        <td><?= isset($data['type']) ? ucfirst(htmlspecialchars($data['type'])) : 'Unknown' ?></td>
                    </tr>
                    <tr>
                        <th>Description</th>
                        <td><?= htmlspecialchars($data['config']['desc'] ?? 'No description available') ?></td>
                    </tr>
                    <tr>
                        <th>Repository URL</th>
                        <td>
                            <?php if (!empty($data['config']['url'])): ?>
                                <a href="<?= htmlspecialchars($data['config']['url']) ?>" target="_blank">
                                    <?= htmlspecialchars($data['config']['url']) ?>
                                </a>
                            <?php else: ?>
                                Not specified
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Default Branch</th>
                        <td><?= htmlspecialchars($data['config']['branch'] ?? 'main') ?></td>
                    </tr>
                </table>
            </div>
            
            <div class="col-md-6">
                <h5>Installation Status</h5>
                <?php if ($data['installed'] ?? false): ?>
                    <div class="alert alert-success">
                        <i class="bi bi-check-circle"></i> Repository is installed
                    </div>
                    <table class="table table-sm">
                        <tr>
                            <th width="30%">Current Branch</th>
                            <td><?= htmlspecialchars($data['details']['branch'] ?? 'unknown') ?></td>
                        </tr>
                        <tr>
                            <th>Last Commit</th>
                            <td><?= htmlspecialchars($data['details']['last_commit'] ?? 'unknown') ?></td>
                        </tr>
                        <tr>
                            <th>Has Changes</th>
                            <td>
                                <?php if ($data['details']['has_changes'] ?? false): ?>
                                    <span class="badge bg-warning text-dark">Uncommitted Changes</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Clean</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                <?php else: ?>
                    <div class="alert alert-warning">
                        <i class="bi bi-exclamation-triangle"></i> Repository is not installed
                    </div>
                    <?php if (!empty($data['details']['error'] ?? null)): ?>
                        <div class="alert alert-danger">
                            <i class="bi bi-exclamation-octagon"></i> 
                            <?= htmlspecialchars($data['details']['error']) ?>
                        </div>
                    <?php else: ?>
                        <table class="table table-sm">
                            <tr>
                                <th width="30%">Available Version</th>
                                <td><?= isset($data['details']['version']) ? substr(htmlspecialchars($data['details']['version']), 0, 7) : 'unknown' ?></td>
                            </tr>
                            <tr>
                                <th>Branch</th>
                                <td><?= htmlspecialchars($data['details']['branch'] ?? $data['config']['branch'] ?? 'main') ?></td>
                            </tr>
                        </table>
                    <?php endif; ?>
                    <?php if (isset($data['type'], $data['name'])): ?>
                        <a href="./?page=sync&type=<?= htmlspecialchars($data['type']) ?>&name=<?= htmlspecialchars($data['name']) ?>" 
                           class="btn btn-primary" data-action="sync">
                            <i class="bi bi-download"></i> Install Now
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if (($data['installed'] ?? false) && !empty($data['history'] ?? [])): ?>
        <div class="mt-4">
            <h5>Recent Commits</h5>
            <div class="table-responsive">
                <table class="table table-sm table-striped">
                    <thead>
                        <tr>
                            <th>Commit</th>
                            <th>Message</th>
                            <th>Author</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($data['history'] as $commit): ?>
                        <tr>
                            <td><code><?= htmlspecialchars($commit['hash'] ?? '') ?></code></td>
                            <td><?= htmlspecialchars($commit['message'] ?? '') ?></td>
                            <td><?= htmlspecialchars($commit['author'] ?? '') ?></td>
                            <td><?= htmlspecialchars($commit['date'] ?? '') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php elseif ($data['installed'] ?? false): ?>
        <div class="mt-4">
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> No commit history available
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>