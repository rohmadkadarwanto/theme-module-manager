<div class="row">
    <div class="col-md-6 mb-4">
        <div class="card h-100">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bi bi-palette"></i> Themes</h5>
                <a href="./index.php?page=sync&type=theme" class="btn btn-sm btn-light">
                    <i class="bi bi-arrow-repeat"></i> Sync All
                </a>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">

                    <?php if (isset($data['repos']['themes']) && is_array($data['repos']['themes'])): ?>
                        <?php foreach ($data['repos']['themes'] as $name => $data['details']): ?>
                            <?php 
                            // Pastikan $data['details'] adalah array
                            $data['details'] = is_array($data['details']) ? $data['details'] : ['desc' => '', 'branch' => 'main'];
                            ?>
                            <a href="./index.php?page=repo_detail&type=theme&name=<?= htmlspecialchars($name) ?>" 
                               class="list-group-item list-group-item-action">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1">
                                        <i class="bi bi-folder"></i> <?= htmlspecialchars($name) ?>
                                        <?php if (isset($data['installed']['themes'][$name])): ?>
                                            <span class="badge bg-success ms-2">Installed</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary ms-2">Not Installed</span>
                                        <?php endif; ?>
                                    </h6>
                                    <small class="text-muted"><?= htmlspecialchars($data['details']['branch'] ?? 'main') ?></small>
                                </div>
                                <p class="mb-1 text-muted"><?= htmlspecialchars($data['details']['desc'] ?? 'No description') ?></p>
                                <?php if (isset($data['installed']['themes'][$name])): ?>
                                <small class="text-muted d-block mt-1">
                                    <i class="bi bi-git"></i> <?= substr($data['installed']['themes'][$name]['version'] ?? '', 0, 7) ?>
                                    (<?= htmlspecialchars($data['installed']['themes'][$name]['branch'] ?? '') ?>)
                                </small>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="list-group-item text-danger">
                            No themes configured or error loading themes
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bagian Modules (struktur serupa) -->
    <div class="col-md-6 mb-4">
        <div class="card h-100">
            <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bi bi-puzzle"></i> Modules</h5>
                <a href="./index.php?page=sync&type=module" class="btn btn-sm btn-light">
                    <i class="bi bi-arrow-repeat"></i> Sync All
                </a>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php if (isset($data['repos']['modules']) && is_array($data['repos']['modules'])): ?>
                        <?php foreach ($data['repos']['modules'] as $name => $data['details']): ?>
                            <a href="./index.php?page=repo_detail&type=modules&name=<?= htmlspecialchars($name) ?>" 
                               class="list-group-item list-group-item-action">
                               <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1">
                                        <i class="bi bi-folder"></i> <?= htmlspecialchars($name) ?>
                                        <?php if (isset($data['installed']['modules'][$name])): ?>
                                            <span class="badge bg-success ms-2">Installed</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary ms-2">Not Installed</span>
                                        <?php endif; ?>
                                    </h6>
                                    <small class="text-muted"><?= htmlspecialchars($data['details']['branch'] ?? 'main') ?></small>
                                </div>
                                <p class="mb-1 text-muted"><?= htmlspecialchars($data['details']['desc'] ?? 'No description') ?></p>
                                <?php if (isset($data['installed']['modules'][$name])): ?>
                                <small class="text-muted d-block mt-1">
                                    <i class="bi bi-git"></i> <?= substr($data['installed']['modules'][$name]['version'] ?? '', 0, 7) ?>
                                    (<?= htmlspecialchars($data['installed']['modules'][$name]['branch'] ?? '') ?>)
                                </small>
                                <?php endif; ?>       
                               
                            </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="list-group-item text-danger">
                            No modules configured or error loading modules
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>