</div>
        <footer class="mt-5 py-3 bg-light">
            <div class="container text-center">
                <p class="mb-0 text-muted">
                    Theme & Module Manager &copy; <?= date('Y') ?>
                </p>
            </div>
        </footer>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/script.js"></script>
</body>
</html>